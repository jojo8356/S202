import os
from math import sqrt

def produit_scalaire(u,v):
    if len(u) != len(v):
        raise ValueError("Les deux vecteurs n'ont pas les memes dimension.")
    return sum(ui*vi for ui, vi in zip(u, v))

def norme(u):
    return sqrt(produit_scalaire(u, u))

def normaliser(u):
    norme_u = norme(u)
    if norme_u == 0:
        return u
    v = []
    for ui in u:
        v.append(ui/norme_u)
    return v

def lister_mots(fichier):
    "Retourne la liste des mots contenus dans le fichier."
    with open(fichier) as f:
        txt = f.read()
    # Liste des caractères (en minuscules).
    caracteres = list(txt.casefold())
    # On ne garde que les lettres et les espaces.
    txt = ''.join(c for c in caracteres if c.isalpha() or c.isspace())
    # On découpe suivant les espaces.
    return txt.split()


def generer_donnees(repertoire):
    """Renvoie les 3 listes suivantes:
       - la liste des documents .txt du répertoire,
       - la liste des vecteurs (non normés) correspondants,
       - la liste complète des mots présents."""
    print('Lecture des données...')
    os.chdir(repertoire)
    docs = [nom for nom in os.listdir('.') if nom.endswith('.txt')]
    # `mots` va contenir tous les mots contenus au moins un document.
    mots = set()
    listes_mots = []
    for fichier in docs:
        l_mots = sorted(lister_mots(fichier))
        mots.update(l_mots)
        listes_mots.append(l_mots)
    mots = sorted(mots)
    print(len(mots), 'mots trouvés.')
    # Maintenant qu'on a la liste complète des mots, on peut générer
    # les vecteurs correspondant au nombre d'occurences de chaque mot.
    print('Génération des vecteurs...')
    vecteurs = [[l.count(mot) for mot in mots] for l in listes_mots]
    return docs, vecteurs, mots

def vecteur_requete(requete, mots):
    "Renvoie le vecteur correspondant à la requete."
    l_mots = requete.casefold().split()
    return [l_mots.count(mot) for mot in mots]
